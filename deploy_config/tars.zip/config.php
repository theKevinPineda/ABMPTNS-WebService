<?php
/**
 * Database config variables
 */
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASSWORD", "");
define("DB_DATABASE", "tars");

/*
 * Google API Key
 */
define("GOOGLE_API_KEY", "AIzaSyDAO5prQIAxP9ovWAdZFk_ZwmGNGh8X5Ao"); // Place your Google API Key
?>

 
