<?

date_default_timezone_set('Etc/GMT-8');
echo date("H:i:s");

?>